# HireKiosk
# Kiosk App (CI)
- Build otomatis via GitHub Actions.
- Debug APK ada di artifacts setiap push ke `main`.
- Release APK: push tag (mis. `v1.0.0`) + isi secrets keystore.

## Jalankan lokal
- Android Studio Narwhal (JDK 21 embedded)
- Sync → Build APKs → app-debug.apk
