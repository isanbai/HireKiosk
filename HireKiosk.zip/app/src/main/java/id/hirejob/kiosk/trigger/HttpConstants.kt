package id.hirejob.kiosk.trigger

object HttpConstants {
    const val DEFAULT_HTTP_HOST = "0.0.0.0"
    const val DEFAULT_HTTP_PORT = 8080
    const val SOCKET_READ_TIMEOUT = 10_000 // ms
}
