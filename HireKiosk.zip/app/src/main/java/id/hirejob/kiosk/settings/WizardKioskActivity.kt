// app/src/main/java/id/hirejob/kiosk/settings/WizardKioskActivity.kt
package id.hirejob.kiosk.settings

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class WizardKioskActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContentView(R.layout.activity_wizard_kiosk)  // if you have a layout
    }
}
